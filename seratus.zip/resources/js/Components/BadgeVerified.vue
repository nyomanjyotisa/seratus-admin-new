<script setup>
import { CheckBadgeIcon } from '@heroicons/vue/24/solid';

</script>

<template>
    <CheckBadgeIcon class="ml-[2px] w-4 h-4 text-primary dark:text-white" v-show="1" />
</template>
