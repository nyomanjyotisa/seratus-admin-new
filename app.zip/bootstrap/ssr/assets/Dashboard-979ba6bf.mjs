import { unref, withCtx, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$2 } from "./Breadcrumb-c30f53fb.mjs";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-dd3db9f0.mjs";
import { Head } from "@inertiajs/vue3";
import "@heroicons/vue/24/solid";
import "./ApplicationLogo-765f8fe2.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Dashboard",
  __ssrInlineRender: true,
  props: {
    transaksiPending: Number,
    transaksiSelesai: Number,
    total_pemasukan: Number,
    total_pengeluaran: Number,
    laba: Number,
    saldo: Number
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Dashboard" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: "Dashboard",
              breadcrumbs: []
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="text-white dark:text-slate-100 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 sm:gap-4 overflow-hidden shadow-sm"${_scopeId}><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>${ssrInterpolate(props.transaksiPending)}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Transaksi Pending </p></div></div></div><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>${ssrInterpolate(props.transaksiSelesai)}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Total Transaksi Selesai </p></div></div></div><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>Rp${ssrInterpolate(props.saldo.toLocaleString())}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Saldo Kas Saat Ini </p></div></div></div><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>Rp${ssrInterpolate(props.total_pemasukan.toLocaleString())}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Total Omzet </p></div></div></div><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>Rp${ssrInterpolate(props.total_pengeluaran.toLocaleString())}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Total Pengeluaran Operasional </p></div></div></div><div${_scopeId}><div class="rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-500/80 items-center overflow-hidden"${_scopeId}><div class="flex flex-col"${_scopeId}><p class="text-4xl font-bold"${_scopeId}>Rp${ssrInterpolate(props.laba.toLocaleString())}</p><p class="text-md md:text-lg uppercase"${_scopeId}> Total Laba </p></div></div></div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: "Dashboard",
                breadcrumbs: []
              }),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "text-white dark:text-slate-100 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 sm:gap-4 overflow-hidden shadow-sm" }, [
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, toDisplayString(props.transaksiPending), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Transaksi Pending ")
                      ])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, toDisplayString(props.transaksiSelesai), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Total Transaksi Selesai ")
                      ])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, "Rp" + toDisplayString(props.saldo.toLocaleString()), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Saldo Kas Saat Ini ")
                      ])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-blue-600/70 dark:bg-blue-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, "Rp" + toDisplayString(props.total_pemasukan.toLocaleString()), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Total Omzet ")
                      ])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-amber-600/70 dark:bg-amber-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, "Rp" + toDisplayString(props.total_pengeluaran.toLocaleString()), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Total Pengeluaran Operasional ")
                      ])
                    ])
                  ]),
                  createVNode("div", null, [
                    createVNode("div", { class: "rounded-none sm:rounded-lg px-4 py-6 flex justify-between bg-green-600/70 dark:bg-green-500/80 items-center overflow-hidden" }, [
                      createVNode("div", { class: "flex flex-col" }, [
                        createVNode("p", { class: "text-4xl font-bold" }, "Rp" + toDisplayString(props.laba.toLocaleString()), 1),
                        createVNode("p", { class: "text-md md:text-lg uppercase" }, " Total Laba ")
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
