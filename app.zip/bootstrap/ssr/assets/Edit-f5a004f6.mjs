import { watchEffect, mergeProps, withCtx, unref, createTextVNode, toDisplayString, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$2, a as _sfc_main$3, b as _sfc_main$4 } from "./TextInput-874f017f.mjs";
import { _ as _sfc_main$1, a as _sfc_main$6 } from "./SecondaryButton-bdd06cd9.mjs";
import { _ as _sfc_main$7 } from "./PrimaryButton-2c41e289.mjs";
import { useForm } from "@inertiajs/vue3";
import { _ as _sfc_main$5 } from "./SelectInput-1a3ac3f3.mjs";
const _sfc_main = {
  __name: "Edit",
  __ssrInlineRender: true,
  props: {
    show: Boolean,
    title: String,
    transaction: Object,
    saldo: Object
  },
  emits: ["close"],
  setup(__props, { emit }) {
    const props = __props;
    const form = useForm({
      amount: "",
      description: "",
      date: new Date().toISOString().substr(0, 10),
      type: ""
    });
    const update = () => {
      var _a, _b;
      console.log(props.saldo);
      console.log((_a = props.saldo) == null ? void 0 : _a.id);
      form.put(route("kas.update", (_b = props.saldo) == null ? void 0 : _b.id), {
        preserveScroll: true,
        onSuccess: () => {
          emit("close");
          form.reset();
        },
        onError: () => null,
        onFinish: () => null
      });
    };
    watchEffect(() => {
      var _a, _b, _c, _d;
      if (props.show) {
        var date = new Date((_a = props.saldo) == null ? void 0 : _a.date);
        date.setHours(date.getHours() + 8);
        form.errors = {};
        form.amount = (_b = props.saldo) == null ? void 0 : _b.amount;
        form.description = (_c = props.saldo) == null ? void 0 : _c.description;
        form.type = (_d = props.saldo) == null ? void 0 : _d.type;
        form.date = date.toISOString().slice(0, 10);
        form.errors = {};
      }
    });
    const sources = [
      {
        value: "masuk",
        label: "Uang Masuk"
      },
      {
        value: "keluar",
        label: "Uang Keluar"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "space-y-6" }, _attrs))}>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        show: props.show,
        onClose: ($event) => emit("close")
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<form class="p-6"${_scopeId}><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100"${_scopeId}>${ssrInterpolate(_ctx.lang().label.edit)} ${ssrInterpolate(props.title)}</h2><div class="my-6 space-y-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "amount",
              value: "Amount"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "amount",
              type: "number",
              class: "mt-1 block w-full",
              modelValue: unref(form).amount,
              "onUpdate:modelValue": ($event) => unref(form).amount = $event,
              placeholder: "ex: 100000",
              error: unref(form).errors.amount
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.amount
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "tipe",
              value: "Tipe"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              id: "tipe",
              class: "mt-1 block w-full",
              modelValue: unref(form).type,
              "onUpdate:modelValue": ($event) => unref(form).type = $event,
              required: "",
              dataSet: sources
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.type
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "description",
              value: "Deskripsi"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "description",
              type: "text",
              class: "mt-1 block w-full",
              modelValue: unref(form).description,
              "onUpdate:modelValue": ($event) => unref(form).description = $event,
              placeholder: "ex: Pandil Rama Sita 50 cm",
              error: unref(form).errors.description
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.description
            }, null, _parent2, _scopeId));
            _push2(`</div><div${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$2, {
              for: "date",
              value: "Tanggal"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "date",
              type: "date",
              class: "mt-1 block w-full",
              modelValue: unref(form).date,
              "onUpdate:modelValue": ($event) => unref(form).date = $event,
              placeholder: "ex: Pandil Rama Sita 50 cm",
              error: unref(form).errors.date
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              class: "mt-2",
              message: unref(form).errors.date
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              disabled: unref(form).processing,
              onClick: ($event) => emit("close")
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(_ctx.lang().button.close)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              class: ["ml-3", { "opacity-25": unref(form).processing }],
              disabled: unref(form).processing,
              onClick: update
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></form>`);
          } else {
            return [
              createVNode("form", {
                class: "p-6",
                onSubmit: withModifiers(update, ["prevent"])
              }, [
                createVNode("h2", { class: "text-lg font-medium text-slate-900 dark:text-slate-100" }, toDisplayString(_ctx.lang().label.edit) + " " + toDisplayString(props.title), 1),
                createVNode("div", { class: "my-6 space-y-4" }, [
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "amount",
                      value: "Amount"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "amount",
                      type: "number",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).amount,
                      "onUpdate:modelValue": ($event) => unref(form).amount = $event,
                      placeholder: "ex: 100000",
                      error: unref(form).errors.amount
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.amount
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "tipe",
                      value: "Tipe"
                    }),
                    createVNode(_sfc_main$5, {
                      id: "tipe",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).type,
                      "onUpdate:modelValue": ($event) => unref(form).type = $event,
                      required: "",
                      dataSet: sources
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.type
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "description",
                      value: "Deskripsi"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "description",
                      type: "text",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).description,
                      "onUpdate:modelValue": ($event) => unref(form).description = $event,
                      placeholder: "ex: Pandil Rama Sita 50 cm",
                      error: unref(form).errors.description
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.description
                    }, null, 8, ["message"])
                  ]),
                  createVNode("div", null, [
                    createVNode(_sfc_main$2, {
                      for: "date",
                      value: "Tanggal"
                    }),
                    createVNode(_sfc_main$3, {
                      id: "date",
                      type: "date",
                      class: "mt-1 block w-full",
                      modelValue: unref(form).date,
                      "onUpdate:modelValue": ($event) => unref(form).date = $event,
                      placeholder: "ex: Pandil Rama Sita 50 cm",
                      error: unref(form).errors.date
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "error"]),
                    createVNode(_sfc_main$4, {
                      class: "mt-2",
                      message: unref(form).errors.date
                    }, null, 8, ["message"])
                  ])
                ]),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode(_sfc_main$6, {
                    disabled: unref(form).processing,
                    onClick: ($event) => emit("close")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.lang().button.close), 1)
                    ]),
                    _: 1
                  }, 8, ["disabled", "onClick"]),
                  createVNode(_sfc_main$7, {
                    class: ["ml-3", { "opacity-25": unref(form).processing }],
                    disabled: unref(form).processing,
                    onClick: update
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save), 1)
                    ]),
                    _: 1
                  }, 8, ["class", "disabled"])
                ])
              ], 40, ["onSubmit"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Saldo/Edit.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
