import { reactive, resolveDirective, withCtx, createTextVNode, mergeProps, unref, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrGetDirectiveProps, ssrRenderList, ssrInterpolate, ssrRenderStyle } from "vue/server-renderer";
import "./AuthenticatedLayout-dd3db9f0.mjs";
import "@inertiajs/vue3";
import { _ as _sfc_main$1 } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$7 } from "./InfoButton-80e469bc.mjs";
import { _ as _sfc_main$6 } from "./DangerButton-00cf94ec.mjs";
import "lodash";
import { TrashIcon, PencilIcon } from "@heroicons/vue/24/solid";
import _sfc_main$2 from "./Create-62ffb481.mjs";
import _sfc_main$4 from "./Edit-97a5d674.mjs";
import _sfc_main$3 from "./Delete-28f5985c.mjs";
import _sfc_main$5 from "./DeleteBulk-1d7fabf7.mjs";
import "./Checkbox-89bfd94c.mjs";
import "./ApplicationLogo-765f8fe2.mjs";
import "@vueuse/core";
import "@headlessui/vue";
import "./TextInput-874f017f.mjs";
import "./SecondaryButton-bdd06cd9.mjs";
import "./SelectInput-1a3ac3f3.mjs";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    productions: Object,
    transaction: Object
  },
  setup(__props) {
    const props = __props;
    const data = reactive({
      selectedId: [],
      multipleSelect: false,
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      production: null
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_tooltip = resolveDirective("tooltip");
      _push(`<!--[--><header class="mb-4"><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100"> Data Transaksi Produksi </h2></header><div class="space-y-4"><div class="px-4 sm:px-0"><div class="rounded-lg overflow-hidden w-fit">`);
      if (__props.transaction.status == "pending") {
        _push(ssrRenderComponent(_sfc_main$1, {
          class: "rounded-none",
          onClick: ($event) => data.createOpen = true
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` Tambah Transaksi Produksi `);
            } else {
              return [
                createTextVNode(" Tambah Transaksi Produksi ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_sfc_main$2, {
        show: data.createOpen,
        onClose: ($event) => data.createOpen = false,
        title: props.title,
        transaction: props.transaction
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        show: data.deleteOpen,
        onClose: ($event) => data.deleteOpen = false,
        production: data.production,
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        show: data.editOpen,
        onClose: ($event) => data.editOpen = false,
        production: data.production,
        title: props.title,
        transaction: props.transaction
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$5, {
        show: data.deleteBulkOpen,
        onClose: ($event) => (data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []),
        selectedId: data.selectedId,
        title: props.title
      }, null, _parent));
      _push(`</div></div><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"><div class="flex justify-between p-2"><div class="flex space-x-2">`);
      _push(ssrRenderComponent(_sfc_main$6, mergeProps({
        onClick: ($event) => data.deleteBulkOpen = true,
        style: data.selectedId.length != 0 ? null : { display: "none" },
        class: "px-3 py-1.5"
      }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete_selected)), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(unref(TrashIcon), { class: "w-5 h-5" })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="overflow-x-auto scrollbar-table"><table class="w-full"><thead class="uppercase text-sm border-t border-slate-200 dark:border-slate-700"><tr class="dark:bg-slate-900/50 text-left"><th class="px-2 py-4 text-center">#</th><th class="px-2 py-4 cursor-pointer"><div class="flex justify-between items-center"><span>Amount</span></div></th><th class="px-2 py-4 cursor-pointer"><div class="flex justify-between items-center"><span>Deskripsi</span></div></th><th class="px-2 py-4 cursor-pointer"><div class="flex justify-between items-center"><span>Tanggal</span></div></th><th class="px-2 py-4 sr-only">Action</th></tr></thead><tbody><!--[-->`);
      ssrRenderList(__props.productions, (production, index) => {
        _push(`<tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center">${ssrInterpolate(++index)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"> Rp${ssrInterpolate(production.amount.toLocaleString())}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"><p style="${ssrRenderStyle({ "white-space": "normal", "word-break": "break-all", "display": "block" })}">${ssrInterpolate(production.description ?? "-")}</p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3">${ssrInterpolate(production.date)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"><div class="flex justify-center items-center"><div class="rounded-md overflow-hidden">`);
        if (__props.transaction.status == "pending") {
          _push(ssrRenderComponent(_sfc_main$7, mergeProps({
            type: "button",
            onClick: ($event) => (data.editOpen = true, data.production = production),
            class: "px-2 py-1.5 rounded-none"
          }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.edit)), {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(PencilIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(PencilIcon), { class: "w-4 h-4" })
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        if (__props.transaction.status == "pending") {
          _push(ssrRenderComponent(_sfc_main$6, mergeProps({
            type: "button",
            onClick: ($event) => (data.deleteOpen = true, data.production = production),
            class: "px-2 py-1.5 rounded-none"
          }, ssrGetDirectiveProps(
            _ctx,
            _directive_tooltip,
            _ctx.lang().tooltip.delete
          )), {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
              } else {
                return [
                  createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                ];
              }
            }),
            _: 2
          }, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Transaction/Production/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
