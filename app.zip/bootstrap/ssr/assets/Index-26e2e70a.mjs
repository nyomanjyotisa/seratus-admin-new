import { reactive, watch, resolveDirective, unref, withCtx, mergeProps, createVNode, withDirectives, openBlock, createBlock, toDisplayString, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderStyle, ssrGetDirectiveProps } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-dd3db9f0.mjs";
import { usePage, useForm, router, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Breadcrumb-c30f53fb.mjs";
import "./TextInput-874f017f.mjs";
import "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$7 } from "./InfoButton-80e469bc.mjs";
import { _ as _sfc_main$3 } from "./SelectInput-1a3ac3f3.mjs";
import "./DangerButton-00cf94ec.mjs";
import pkg from "lodash";
import { _ as _sfc_main$8 } from "./Pagination-912d85c3.mjs";
import { EyeIcon } from "@heroicons/vue/24/solid";
import _sfc_main$4 from "./Create-6ebf9d75.mjs";
import _sfc_main$5 from "./Delete-72f9f45e.mjs";
import _sfc_main$6 from "./DeleteBulk-6378887f.mjs";
import "./Checkbox-89bfd94c.mjs";
import "./ApplicationLogo-765f8fe2.mjs";
import "@vueuse/core";
import "@headlessui/vue";
import "./SecondaryButton-bdd06cd9.mjs";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    filters: Object,
    transactions: Object,
    expenses: Object,
    otherIncomes: Object,
    roles: Object,
    breadcrumbs: Object,
    perPage: Number,
    isDone: Boolean,
    year: String,
    month: String,
    total_pemasukan: Number,
    total_pengeluaran: Number,
    laba: Number
  },
  setup(__props) {
    const props = __props;
    const { _, debounce, pickBy } = pkg;
    const data = reactive({
      params: {
        search: props.filters.search,
        field: props.filters.field,
        order: props.filters.order,
        perPage: props.perPage
      },
      selectedId: [],
      multipleSelect: false,
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      transaction: null,
      dataSet: usePage().props.app.perpage
    });
    const form = useForm({
      year: props.year,
      month: props.month
    });
    watch(
      () => _.cloneDeep(data.params),
      debounce(() => {
        let params = pickBy(data.params);
        router.get(route("transaction.index"), params, {
          replace: true,
          preserveState: true,
          preserveScroll: true
        });
      }, 150)
    );
    const applyFilter = () => {
      router.get(route("report", { year: form.year, month: form.month }));
    };
    const years = [
      {
        value: "2022",
        label: "2022"
      },
      {
        value: "2023",
        label: "2023"
      },
      {
        value: "2024",
        label: "2024"
      }
    ];
    const months = [
      {
        value: "1",
        label: "Januari"
      },
      {
        value: "2",
        label: "Februari"
      },
      {
        value: "3",
        label: "Maret"
      },
      {
        value: "4",
        label: "April"
      },
      {
        value: "5",
        label: "Mei"
      },
      {
        value: "6",
        label: "Juni"
      },
      {
        value: "7",
        label: "Juli"
      },
      {
        value: "8",
        label: "Agustus"
      },
      {
        value: "9",
        label: "September"
      },
      {
        value: "10",
        label: "Oktober"
      },
      {
        value: "11",
        label: "November"
      },
      {
        value: "12",
        label: "Desember"
      }
    ];
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_tooltip = resolveDirective("tooltip");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_2, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="px-4 sm:px-0"${_scopeId}><div class="rounded-lg overflow-hidden w-fit"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "status",
              class: "mt-1",
              modelValue: unref(form).year,
              "onUpdate:modelValue": ($event) => unref(form).year = $event,
              required: "",
              dataSet: years,
              onChange: applyFilter
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$3, {
              id: "status",
              class: "mt-1 ml-3",
              modelValue: unref(form).month,
              "onUpdate:modelValue": ($event) => unref(form).month = $event,
              required: "",
              dataSet: months,
              onChange: applyFilter
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$4, {
              show: data.createOpen,
              onClose: ($event) => data.createOpen = false,
              roles: props.roles,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              show: data.deleteOpen,
              onClose: ($event) => data.deleteOpen = false,
              transaction: data.transaction,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              show: data.deleteBulkOpen,
              onClose: ($event) => (data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []),
              selectedId: data.selectedId,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><table${_scopeId}><tbody${_scopeId}><tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}> Total Pemasukan </td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><strong${_scopeId}> Rp${ssrInterpolate(__props.total_pemasukan.toLocaleString())}</strong></td></tr><tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}> Total Pengeluaran </td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><strong${_scopeId}> Rp${ssrInterpolate(__props.total_pengeluaran.toLocaleString())}</strong></td></tr><tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}> Laba </td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><strong${_scopeId}> Rp${ssrInterpolate(__props.laba.toLocaleString())}</strong></td></tr></tbody></table><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100"${_scopeId}> Transaksi </h2><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-slate-200 dark:border-slate-700"${_scopeId}><tr class="dark:bg-slate-900/50 text-left"${_scopeId}><th class="px-2 py-4 text-center"${_scopeId}>#</th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Unique Code</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Status</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Laba</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Sumber</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Tanggal</span></div></th><th class="px-2 py-4 sr-only"${_scopeId}>Action</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.transactions.data, (transaction, index) => {
              _push2(`<tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}>${ssrInterpolate(++index)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p${_scopeId}>${ssrInterpolate(transaction.unique_code ?? "-")}</p><p style="${ssrRenderStyle({ "white-space": "normal", "word-break": "break-all", "display": "block" })}"${_scopeId}>${ssrInterpolate(transaction.description ?? "-")}</p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>`);
              if (transaction.sales_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Penjualan (${ssrInterpolate(transaction.sales_count)}) - Rp${ssrInterpolate(transaction.sales_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-red-600"${_scopeId}> Penjualan (0) </p>`);
              }
              if (transaction.productions_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Produksi (${ssrInterpolate(transaction.productions_count)}) - Rp${ssrInterpolate(transaction.productions_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-red-600"${_scopeId}> Produksi (0) </p>`);
              }
              if (transaction.expenses_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Pengeluaran lain (${ssrInterpolate(transaction.expenses_count)}) - Rp${ssrInterpolate(transaction.expenses_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-yellow-600"${_scopeId}> Pengeluaran lain (0) </p>`);
              }
              if (transaction.other_incomes_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Pemasukan lain (${ssrInterpolate(transaction.other_incomes_count)}) - Rp${ssrInterpolate(transaction.other_incomes_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-yellow-600"${_scopeId}> Pemasukan lain (0) </p>`);
              }
              _push2(`</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p${_scopeId}><strong${_scopeId}> Rp${ssrInterpolate(transaction.total.toLocaleString() ?? "-")}</strong></p><p${_scopeId}>${ssrInterpolate(transaction.persentase_laba ?? "-")} % </p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(transaction.source)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(transaction.date)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><div class="flex justify-center items-center"${_scopeId}><div class="rounded-md overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("transaction.show", transaction)
              }, {
                default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$7, mergeProps({
                      type: "button",
                      class: "px-2 py-1.5 rounded-none"
                    }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.edit)), {
                      default: withCtx((_4, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(unref(EyeIcon), { class: "w-4 h-4" }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      withDirectives((openBlock(), createBlock(_sfc_main$7, {
                        type: "button",
                        class: "px-2 py-1.5 rounded-none"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                        ]),
                        _: 1
                      })), [
                        [_directive_tooltip, _ctx.lang().tooltip.edit]
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              _push2(`</div></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="flex justify-between items-center p-2 border-t border-slate-200 dark:border-slate-700"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              links: props.transactions,
              filters: data.params
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100 mt-10 mb-5"${_scopeId}> Pengeluaran Lainnya </h2><div class="space-y-4"${_scopeId}><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-slate-200 dark:border-slate-700"${_scopeId}><tr class="dark:bg-slate-900/50 text-left"${_scopeId}><th class="px-2 py-4 text-center"${_scopeId}>#</th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Amount</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Deskripsi</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Tanggal</span></div></th><th class="px-2 py-4 sr-only"${_scopeId}>Action</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.expenses.data, (expense, index) => {
              _push2(`<tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}>${ssrInterpolate(++index)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}> Rp${ssrInterpolate(parseInt(expense.amount).toLocaleString())}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p style="${ssrRenderStyle({ "white-space": "normal", "word-break": "break-all", "display": "block" })}"${_scopeId}>${ssrInterpolate(expense.description ?? "-")}</p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(expense.date)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100 mt-10 mb-5"${_scopeId}> Pendapatan Lainnya </h2><div class="space-y-4"${_scopeId}><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-slate-200 dark:border-slate-700"${_scopeId}><tr class="dark:bg-slate-900/50 text-left"${_scopeId}><th class="px-2 py-4 text-center"${_scopeId}>#</th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Amount</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Deskripsi</span></div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Tanggal</span></div></th><th class="px-2 py-4 sr-only"${_scopeId}>Action</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.otherIncomes.data, (otherIncome, index) => {
              _push2(`<tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}>${ssrInterpolate(++index)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}> Rp${ssrInterpolate(parseInt(otherIncome.amount).toLocaleString())}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p style="${ssrRenderStyle({ "white-space": "normal", "word-break": "break-all", "display": "block" })}"${_scopeId}>${ssrInterpolate(otherIncome.description ?? "-")}</p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(otherIncome.date)}</td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"]),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "px-4 sm:px-0" }, [
                  createVNode("div", { class: "rounded-lg overflow-hidden w-fit" }, [
                    createVNode(_sfc_main$3, {
                      id: "status",
                      class: "mt-1",
                      modelValue: unref(form).year,
                      "onUpdate:modelValue": ($event) => unref(form).year = $event,
                      required: "",
                      dataSet: years,
                      onChange: applyFilter
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$3, {
                      id: "status",
                      class: "mt-1 ml-3",
                      modelValue: unref(form).month,
                      "onUpdate:modelValue": ($event) => unref(form).month = $event,
                      required: "",
                      dataSet: months,
                      onChange: applyFilter
                    }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                    createVNode(_sfc_main$4, {
                      show: data.createOpen,
                      onClose: ($event) => data.createOpen = false,
                      roles: props.roles,
                      title: props.title
                    }, null, 8, ["show", "onClose", "roles", "title"]),
                    createVNode(_sfc_main$5, {
                      show: data.deleteOpen,
                      onClose: ($event) => data.deleteOpen = false,
                      transaction: data.transaction,
                      title: props.title
                    }, null, 8, ["show", "onClose", "transaction", "title"]),
                    createVNode(_sfc_main$6, {
                      show: data.deleteBulkOpen,
                      onClose: ($event) => (data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []),
                      selectedId: data.selectedId,
                      title: props.title
                    }, null, 8, ["show", "onClose", "selectedId", "title"])
                  ])
                ]),
                createVNode("table", null, [
                  createVNode("tbody", null, [
                    createVNode("tr", { class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20" }, [
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, " Total Pemasukan "),
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                        createVNode("strong", null, " Rp" + toDisplayString(__props.total_pemasukan.toLocaleString()), 1)
                      ])
                    ]),
                    createVNode("tr", { class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20" }, [
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, " Total Pengeluaran "),
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                        createVNode("strong", null, " Rp" + toDisplayString(__props.total_pengeluaran.toLocaleString()), 1)
                      ])
                    ]),
                    createVNode("tr", { class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20" }, [
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, " Laba "),
                      createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                        createVNode("strong", null, " Rp" + toDisplayString(__props.laba.toLocaleString()), 1)
                      ])
                    ])
                  ])
                ]),
                createVNode("h2", { class: "text-lg font-medium text-slate-900 dark:text-slate-100" }, " Transaksi "),
                createVNode("div", { class: "relative bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-slate-200 dark:border-slate-700" }, [
                        createVNode("tr", { class: "dark:bg-slate-900/50 text-left" }, [
                          createVNode("th", { class: "px-2 py-4 text-center" }, "#"),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Unique Code")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Status")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Laba")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Sumber")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Tanggal")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 sr-only" }, "Action")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.transactions.data, (transaction, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center" }, toDisplayString(++index), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", null, toDisplayString(transaction.unique_code ?? "-"), 1),
                              createVNode("p", { style: { "white-space": "normal", "word-break": "break-all", "display": "block" } }, toDisplayString(transaction.description ?? "-"), 1)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              transaction.sales_count > 0 ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-green-600"
                              }, " Penjualan (" + toDisplayString(transaction.sales_count) + ") - Rp" + toDisplayString(transaction.sales_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 1,
                                class: "text-red-600"
                              }, " Penjualan (0) ")),
                              transaction.productions_count > 0 ? (openBlock(), createBlock("p", {
                                key: 2,
                                class: "text-green-600"
                              }, " Produksi (" + toDisplayString(transaction.productions_count) + ") - Rp" + toDisplayString(transaction.productions_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 3,
                                class: "text-red-600"
                              }, " Produksi (0) ")),
                              transaction.expenses_count > 0 ? (openBlock(), createBlock("p", {
                                key: 4,
                                class: "text-green-600"
                              }, " Pengeluaran lain (" + toDisplayString(transaction.expenses_count) + ") - Rp" + toDisplayString(transaction.expenses_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 5,
                                class: "text-yellow-600"
                              }, " Pengeluaran lain (0) ")),
                              transaction.other_incomes_count > 0 ? (openBlock(), createBlock("p", {
                                key: 6,
                                class: "text-green-600"
                              }, " Pemasukan lain (" + toDisplayString(transaction.other_incomes_count) + ") - Rp" + toDisplayString(transaction.other_incomes_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 7,
                                class: "text-yellow-600"
                              }, " Pemasukan lain (0) "))
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", null, [
                                createVNode("strong", null, " Rp" + toDisplayString(transaction.total.toLocaleString() ?? "-"), 1)
                              ]),
                              createVNode("p", null, toDisplayString(transaction.persentase_laba ?? "-") + " % ", 1)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(transaction.source), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(transaction.date), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("div", { class: "flex justify-center items-center" }, [
                                createVNode("div", { class: "rounded-md overflow-hidden" }, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("transaction.show", transaction)
                                  }, {
                                    default: withCtx(() => [
                                      withDirectives((openBlock(), createBlock(_sfc_main$7, {
                                        type: "button",
                                        class: "px-2 py-1.5 rounded-none"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                                        ]),
                                        _: 1
                                      })), [
                                        [_directive_tooltip, _ctx.lang().tooltip.edit]
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["href"])
                                ])
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-between items-center p-2 border-t border-slate-200 dark:border-slate-700" }, [
                    createVNode(_sfc_main$8, {
                      links: props.transactions,
                      filters: data.params
                    }, null, 8, ["links", "filters"])
                  ])
                ])
              ]),
              createVNode("h2", { class: "text-lg font-medium text-slate-900 dark:text-slate-100 mt-10 mb-5" }, " Pengeluaran Lainnya "),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "relative bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-slate-200 dark:border-slate-700" }, [
                        createVNode("tr", { class: "dark:bg-slate-900/50 text-left" }, [
                          createVNode("th", { class: "px-2 py-4 text-center" }, "#"),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Amount")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Deskripsi")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Tanggal")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 sr-only" }, "Action")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.expenses.data, (expense, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center" }, toDisplayString(++index), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, " Rp" + toDisplayString(parseInt(expense.amount).toLocaleString()), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", { style: { "white-space": "normal", "word-break": "break-all", "display": "block" } }, toDisplayString(expense.description ?? "-"), 1)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(expense.date), 1)
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ]),
              createVNode("h2", { class: "text-lg font-medium text-slate-900 dark:text-slate-100 mt-10 mb-5" }, " Pendapatan Lainnya "),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "relative bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-slate-200 dark:border-slate-700" }, [
                        createVNode("tr", { class: "dark:bg-slate-900/50 text-left" }, [
                          createVNode("th", { class: "px-2 py-4 text-center" }, "#"),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Amount")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Deskripsi")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 cursor-pointer" }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Tanggal")
                            ])
                          ]),
                          createVNode("th", { class: "px-2 py-4 sr-only" }, "Action")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.otherIncomes.data, (otherIncome, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center" }, toDisplayString(++index), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, " Rp" + toDisplayString(parseInt(otherIncome.amount).toLocaleString()), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", { style: { "white-space": "normal", "word-break": "break-all", "display": "block" } }, toDisplayString(otherIncome.description ?? "-"), 1)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(otherIncome.date), 1)
                          ]);
                        }), 128))
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Report/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
