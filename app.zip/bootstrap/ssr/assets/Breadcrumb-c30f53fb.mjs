import { mergeProps, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderList } from "vue/server-renderer";
import { ChevronRightIcon } from "@heroicons/vue/24/solid";
import { Link } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "Breadcrumb",
  __ssrInlineRender: true,
  props: {
    title: String,
    breadcrumbs: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center justify-between py-4 px-4 sm:px-0 text-slate-500 dark:text-slate-300" }, _attrs))}><p>${ssrInterpolate(__props.title)}</p><div class="hidden sm:flex space-x-2 items-center">`);
      _push(ssrRenderComponent(unref(Link), {
        href: _ctx.route("dashboard"),
        style: __props.breadcrumbs.length != 0 ? null : { display: "none" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Dashboard `);
          } else {
            return [
              createTextVNode(" Dashboard ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList(__props.breadcrumbs, (breadcrumb, index) => {
        _push(`<div class="flex items-center space-x-2">`);
        _push(ssrRenderComponent(unref(ChevronRightIcon), { class: "w-3 h-3" }, null, _parent));
        _push(ssrRenderComponent(unref(Link), {
          href: breadcrumb.href
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(breadcrumb.label)}`);
            } else {
              return [
                createTextVNode(toDisplayString(breadcrumb.label), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div>`);
      });
      _push(`<!--]--></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Breadcrumb.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
