import { reactive, watch, resolveDirective, unref, withCtx, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, mergeProps, createVNode, withDirectives, vShow, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrGetDirectiveProps, ssrRenderList, ssrRenderStyle, ssrRenderClass } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-dd3db9f0.mjs";
import { usePage, router, Head, Link } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Breadcrumb-c30f53fb.mjs";
import { a as _sfc_main$a } from "./TextInput-874f017f.mjs";
import { _ as _sfc_main$3 } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$b } from "./InfoButton-80e469bc.mjs";
import { _ as _sfc_main$8 } from "./SelectInput-1a3ac3f3.mjs";
import { _ as _sfc_main$9 } from "./DangerButton-00cf94ec.mjs";
import pkg from "lodash";
import { _ as _sfc_main$c } from "./Pagination-912d85c3.mjs";
import { TrashIcon, ChevronUpDownIcon, EyeIcon } from "@heroicons/vue/24/solid";
import _sfc_main$5 from "./Create-6ebf9d75.mjs";
import _sfc_main$6 from "./Delete-72f9f45e.mjs";
import _sfc_main$7 from "./DeleteBulk-6378887f.mjs";
import "./Checkbox-89bfd94c.mjs";
import { a as _sfc_main$4 } from "./SecondaryButton-bdd06cd9.mjs";
import "./ApplicationLogo-765f8fe2.mjs";
import "@vueuse/core";
import "@headlessui/vue";
const _sfc_main = {
  __name: "Index",
  __ssrInlineRender: true,
  props: {
    title: String,
    filters: Object,
    transactions: Object,
    roles: Object,
    breadcrumbs: Object,
    perPage: Number,
    isDone: Boolean
  },
  setup(__props) {
    const props = __props;
    const { _, debounce, pickBy } = pkg;
    const data = reactive({
      params: {
        search: props.filters.search,
        field: props.filters.field,
        order: props.filters.order,
        perPage: props.perPage
      },
      selectedId: [],
      multipleSelect: false,
      createOpen: false,
      editOpen: false,
      deleteOpen: false,
      deleteBulkOpen: false,
      transaction: null,
      dataSet: usePage().props.app.perpage
    });
    const order = (field) => {
      data.params.field = field;
      data.params.order = data.params.order === "asc" ? "desc" : "asc";
    };
    watch(
      () => _.cloneDeep(data.params),
      debounce(() => {
        let params = pickBy(data.params);
        if (props.title == "Transaksi list Done") {
          router.get(route("transaction.index.done"), params, {
            replace: true,
            preserveState: true,
            preserveScroll: true
          });
        } else {
          router.get(route("transaction.index"), params, {
            replace: true,
            preserveState: true,
            preserveScroll: true
          });
        }
      }, 150)
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_tooltip = resolveDirective("tooltip");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: props.title
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_2, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: __props.title,
              breadcrumbs: __props.breadcrumbs
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="px-4 sm:px-0"${_scopeId}><div class="rounded-lg overflow-hidden w-fit"${_scopeId}>`);
            if (props.isDone == false) {
              _push2(ssrRenderComponent(_sfc_main$3, {
                class: "rounded",
                onClick: ($event) => data.createOpen = true
              }, {
                default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`${ssrInterpolate(_ctx.lang().button.add)}`);
                  } else {
                    return [
                      createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            _push2(ssrRenderComponent(unref(Link), {
              href: _ctx.route("transaction.index.done")
            }, {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  if (props.isDone == false) {
                    _push3(ssrRenderComponent(_sfc_main$4, { class: "rounded ml-3" }, {
                      default: withCtx((_4, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(` Lihat Transaksi Selesai `);
                        } else {
                          return [
                            createTextVNode(" Lihat Transaksi Selesai ")
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                  } else {
                    _push3(`<!---->`);
                  }
                } else {
                  return [
                    props.isDone == false ? (openBlock(), createBlock(_sfc_main$4, {
                      key: 0,
                      class: "rounded ml-3"
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Lihat Transaksi Selesai ")
                      ]),
                      _: 1
                    })) : createCommentVNode("", true)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$5, {
              show: data.createOpen,
              onClose: ($event) => data.createOpen = false,
              roles: props.roles,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$6, {
              show: data.deleteOpen,
              onClose: ($event) => data.deleteOpen = false,
              transaction: data.transaction,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$7, {
              show: data.deleteBulkOpen,
              onClose: ($event) => (data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []),
              selectedId: data.selectedId,
              title: props.title
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="relative bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}><div class="flex justify-between p-2"${_scopeId}><div class="flex space-x-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$8, {
              modelValue: data.params.perPage,
              "onUpdate:modelValue": ($event) => data.params.perPage = $event,
              dataSet: data.dataSet
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_sfc_main$9, mergeProps({
              onClick: ($event) => data.deleteBulkOpen = true,
              style: data.selectedId.length != 0 ? null : { display: "none" },
              class: "px-3 py-1.5"
            }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.delete_selected)), {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-5 h-5" }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_sfc_main$a, {
              modelValue: data.params.search,
              "onUpdate:modelValue": ($event) => data.params.search = $event,
              type: "text",
              class: "ml-3 block w-full rounded-lg",
              placeholder: _ctx.lang().placeholder.search
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="overflow-x-auto scrollbar-table"${_scopeId}><table class="w-full"${_scopeId}><thead class="uppercase text-sm border-t border-slate-200 dark:border-slate-700"${_scopeId}><tr class="dark:bg-slate-900/50 text-left"${_scopeId}><th class="px-2 py-4 text-center"${_scopeId}>#</th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Unique Code</span>`);
            _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
            _push2(`</div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Status</span>`);
            _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
            _push2(`</div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Laba</span>`);
            _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
            _push2(`</div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Sumber</span>`);
            _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
            _push2(`</div></th><th class="px-2 py-4 cursor-pointer"${_scopeId}><div class="flex justify-between items-center"${_scopeId}><span${_scopeId}>Tanggal</span>`);
            _push2(ssrRenderComponent(unref(ChevronUpDownIcon), { class: "w-4 h-4" }, null, _parent2, _scopeId));
            _push2(`</div></th><th class="px-2 py-4 sr-only"${_scopeId}>Action</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(__props.transactions.data, (transaction, index) => {
              _push2(`<tr class="border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"${_scopeId}><td class="whitespace-nowrap py-4 px-2 sm:py-3 text-center"${_scopeId}>${ssrInterpolate(++index)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p${_scopeId}>${ssrInterpolate(transaction.unique_code ?? "-")}</p><p style="${ssrRenderStyle({ "white-space": "normal", "word-break": "break-all", "display": "block" })}"${_scopeId}>${ssrInterpolate(transaction.description ?? "-")}</p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>`);
              if (transaction.sales_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Penjualan (${ssrInterpolate(transaction.sales_count)}) - Rp${ssrInterpolate(transaction.sales_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-red-600"${_scopeId}> Penjualan (0) </p>`);
              }
              if (transaction.productions_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Produksi (${ssrInterpolate(transaction.productions_count)}) - Rp${ssrInterpolate(transaction.productions_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-red-600"${_scopeId}> Produksi (0) </p>`);
              }
              if (transaction.source != "tokped") {
                _push2(`<p class="text-yellow-600"${_scopeId}> Pengeluaran lain (0) </p>`);
              } else {
                _push2(`<p class="${ssrRenderClass(transaction.source == "tokped" && transaction.expenses_count == 0 ? "text-red-600" : "text-green-600")}"${_scopeId}> Pengeluaran lain (${ssrInterpolate(transaction.expenses_count)}) - Rp${ssrInterpolate(transaction.expenses_total.toLocaleString())}</p>`);
              }
              if (transaction.other_incomes_count > 0) {
                _push2(`<p class="text-green-600"${_scopeId}> Pemasukan lain (${ssrInterpolate(transaction.other_incomes_count)}) - Rp${ssrInterpolate(transaction.other_incomes_total.toLocaleString())}</p>`);
              } else {
                _push2(`<p class="text-yellow-600"${_scopeId}> Pemasukan lain (0) </p>`);
              }
              _push2(`</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><p${_scopeId}><strong${_scopeId}> Rp${ssrInterpolate(transaction.total.toLocaleString() ?? "-")}</strong></p><p class="${ssrRenderClass(transaction.persentase_laba > 60 || transaction.persentase_laba < 30 ? "text-red-600" : "")}"${_scopeId}>${ssrInterpolate(transaction.persentase_laba ?? "-")} % </p></td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(transaction.source)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}>${ssrInterpolate(transaction.date)}</td><td class="whitespace-nowrap py-4 px-2 sm:py-3"${_scopeId}><div class="flex justify-center items-center"${_scopeId}><div class="rounded-md overflow-hidden"${_scopeId}>`);
              _push2(ssrRenderComponent(unref(Link), {
                href: _ctx.route("transaction.show", transaction)
              }, {
                default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_sfc_main$b, mergeProps({
                      type: "button",
                      class: "px-2 py-1.5 rounded-none"
                    }, ssrGetDirectiveProps(_ctx, _directive_tooltip, _ctx.lang().tooltip.edit)), {
                      default: withCtx((_4, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(ssrRenderComponent(unref(EyeIcon), { class: "w-4 h-4" }, null, _parent4, _scopeId3));
                        } else {
                          return [
                            createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  } else {
                    return [
                      withDirectives((openBlock(), createBlock(_sfc_main$b, {
                        type: "button",
                        class: "px-2 py-1.5 rounded-none"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                        ]),
                        _: 1
                      })), [
                        [_directive_tooltip, _ctx.lang().tooltip.edit]
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
              if (props.isDone == false) {
                _push2(ssrRenderComponent(_sfc_main$9, mergeProps({
                  type: "button",
                  onClick: ($event) => (data.deleteOpen = true, data.transaction = transaction),
                  class: "px-2 py-1.5 rounded-none"
                }, ssrGetDirectiveProps(
                  _ctx,
                  _directive_tooltip,
                  _ctx.lang().tooltip.delete
                )), {
                  default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(unref(TrashIcon), { class: "w-4 h-4" }, null, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div></div></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="flex justify-between items-center p-2 border-t border-slate-200 dark:border-slate-700"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$c, {
              links: props.transactions,
              filters: data.params
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: __props.title,
                breadcrumbs: __props.breadcrumbs
              }, null, 8, ["title", "breadcrumbs"]),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "px-4 sm:px-0" }, [
                  createVNode("div", { class: "rounded-lg overflow-hidden w-fit" }, [
                    props.isDone == false ? (openBlock(), createBlock(_sfc_main$3, {
                      key: 0,
                      class: "rounded",
                      onClick: ($event) => data.createOpen = true
                    }, {
                      default: withCtx(() => [
                        createTextVNode(toDisplayString(_ctx.lang().button.add), 1)
                      ]),
                      _: 1
                    }, 8, ["onClick"])) : createCommentVNode("", true),
                    createVNode(unref(Link), {
                      href: _ctx.route("transaction.index.done")
                    }, {
                      default: withCtx(() => [
                        props.isDone == false ? (openBlock(), createBlock(_sfc_main$4, {
                          key: 0,
                          class: "rounded ml-3"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Lihat Transaksi Selesai ")
                          ]),
                          _: 1
                        })) : createCommentVNode("", true)
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_sfc_main$5, {
                      show: data.createOpen,
                      onClose: ($event) => data.createOpen = false,
                      roles: props.roles,
                      title: props.title
                    }, null, 8, ["show", "onClose", "roles", "title"]),
                    createVNode(_sfc_main$6, {
                      show: data.deleteOpen,
                      onClose: ($event) => data.deleteOpen = false,
                      transaction: data.transaction,
                      title: props.title
                    }, null, 8, ["show", "onClose", "transaction", "title"]),
                    createVNode(_sfc_main$7, {
                      show: data.deleteBulkOpen,
                      onClose: ($event) => (data.deleteBulkOpen = false, data.multipleSelect = false, data.selectedId = []),
                      selectedId: data.selectedId,
                      title: props.title
                    }, null, 8, ["show", "onClose", "selectedId", "title"])
                  ])
                ]),
                createVNode("div", { class: "relative bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode("div", { class: "flex justify-between p-2" }, [
                    createVNode("div", { class: "flex space-x-2" }, [
                      createVNode(_sfc_main$8, {
                        modelValue: data.params.perPage,
                        "onUpdate:modelValue": ($event) => data.params.perPage = $event,
                        dataSet: data.dataSet
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "dataSet"]),
                      withDirectives((openBlock(), createBlock(_sfc_main$9, {
                        onClick: ($event) => data.deleteBulkOpen = true,
                        class: "px-3 py-1.5"
                      }, {
                        default: withCtx(() => [
                          createVNode(unref(TrashIcon), { class: "w-5 h-5" })
                        ]),
                        _: 1
                      }, 8, ["onClick"])), [
                        [
                          vShow,
                          data.selectedId.length != 0
                        ],
                        [_directive_tooltip, _ctx.lang().tooltip.delete_selected]
                      ])
                    ]),
                    createVNode(_sfc_main$a, {
                      modelValue: data.params.search,
                      "onUpdate:modelValue": ($event) => data.params.search = $event,
                      type: "text",
                      class: "ml-3 block w-full rounded-lg",
                      placeholder: _ctx.lang().placeholder.search
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "placeholder"])
                  ]),
                  createVNode("div", { class: "overflow-x-auto scrollbar-table" }, [
                    createVNode("table", { class: "w-full" }, [
                      createVNode("thead", { class: "uppercase text-sm border-t border-slate-200 dark:border-slate-700" }, [
                        createVNode("tr", { class: "dark:bg-slate-900/50 text-left" }, [
                          createVNode("th", { class: "px-2 py-4 text-center" }, "#"),
                          createVNode("th", {
                            class: "px-2 py-4 cursor-pointer",
                            onClick: ($event) => order("unique_code")
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Unique Code"),
                              createVNode(unref(ChevronUpDownIcon), { class: "w-4 h-4" })
                            ])
                          ], 8, ["onClick"]),
                          createVNode("th", {
                            class: "px-2 py-4 cursor-pointer",
                            onClick: ($event) => order("status")
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Status"),
                              createVNode(unref(ChevronUpDownIcon), { class: "w-4 h-4" })
                            ])
                          ], 8, ["onClick"]),
                          createVNode("th", {
                            class: "px-2 py-4 cursor-pointer",
                            onClick: ($event) => order("status")
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Laba"),
                              createVNode(unref(ChevronUpDownIcon), { class: "w-4 h-4" })
                            ])
                          ], 8, ["onClick"]),
                          createVNode("th", {
                            class: "px-2 py-4 cursor-pointer",
                            onClick: ($event) => order("source")
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Sumber"),
                              createVNode(unref(ChevronUpDownIcon), { class: "w-4 h-4" })
                            ])
                          ], 8, ["onClick"]),
                          createVNode("th", {
                            class: "px-2 py-4 cursor-pointer",
                            onClick: ($event) => order("date")
                          }, [
                            createVNode("div", { class: "flex justify-between items-center" }, [
                              createVNode("span", null, "Tanggal"),
                              createVNode(unref(ChevronUpDownIcon), { class: "w-4 h-4" })
                            ])
                          ], 8, ["onClick"]),
                          createVNode("th", { class: "px-2 py-4 sr-only" }, "Action")
                        ])
                      ]),
                      createVNode("tbody", null, [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.transactions.data, (transaction, index) => {
                          return openBlock(), createBlock("tr", {
                            key: index,
                            class: "border-t border-slate-200 dark:border-slate-700 hover:bg-slate-200/30 hover:dark:bg-slate-900/20"
                          }, [
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3 text-center" }, toDisplayString(++index), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", null, toDisplayString(transaction.unique_code ?? "-"), 1),
                              createVNode("p", { style: { "white-space": "normal", "word-break": "break-all", "display": "block" } }, toDisplayString(transaction.description ?? "-"), 1)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              transaction.sales_count > 0 ? (openBlock(), createBlock("p", {
                                key: 0,
                                class: "text-green-600"
                              }, " Penjualan (" + toDisplayString(transaction.sales_count) + ") - Rp" + toDisplayString(transaction.sales_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 1,
                                class: "text-red-600"
                              }, " Penjualan (0) ")),
                              transaction.productions_count > 0 ? (openBlock(), createBlock("p", {
                                key: 2,
                                class: "text-green-600"
                              }, " Produksi (" + toDisplayString(transaction.productions_count) + ") - Rp" + toDisplayString(transaction.productions_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 3,
                                class: "text-red-600"
                              }, " Produksi (0) ")),
                              transaction.source != "tokped" ? (openBlock(), createBlock("p", {
                                key: 4,
                                class: "text-yellow-600"
                              }, " Pengeluaran lain (0) ")) : (openBlock(), createBlock("p", {
                                key: 5,
                                class: transaction.source == "tokped" && transaction.expenses_count == 0 ? "text-red-600" : "text-green-600"
                              }, " Pengeluaran lain (" + toDisplayString(transaction.expenses_count) + ") - Rp" + toDisplayString(transaction.expenses_total.toLocaleString()), 3)),
                              transaction.other_incomes_count > 0 ? (openBlock(), createBlock("p", {
                                key: 6,
                                class: "text-green-600"
                              }, " Pemasukan lain (" + toDisplayString(transaction.other_incomes_count) + ") - Rp" + toDisplayString(transaction.other_incomes_total.toLocaleString()), 1)) : (openBlock(), createBlock("p", {
                                key: 7,
                                class: "text-yellow-600"
                              }, " Pemasukan lain (0) "))
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("p", null, [
                                createVNode("strong", null, " Rp" + toDisplayString(transaction.total.toLocaleString() ?? "-"), 1)
                              ]),
                              createVNode("p", {
                                class: transaction.persentase_laba > 60 || transaction.persentase_laba < 30 ? "text-red-600" : ""
                              }, toDisplayString(transaction.persentase_laba ?? "-") + " % ", 3)
                            ]),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(transaction.source), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, toDisplayString(transaction.date), 1),
                            createVNode("td", { class: "whitespace-nowrap py-4 px-2 sm:py-3" }, [
                              createVNode("div", { class: "flex justify-center items-center" }, [
                                createVNode("div", { class: "rounded-md overflow-hidden" }, [
                                  createVNode(unref(Link), {
                                    href: _ctx.route("transaction.show", transaction)
                                  }, {
                                    default: withCtx(() => [
                                      withDirectives((openBlock(), createBlock(_sfc_main$b, {
                                        type: "button",
                                        class: "px-2 py-1.5 rounded-none"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(unref(EyeIcon), { class: "w-4 h-4" })
                                        ]),
                                        _: 1
                                      })), [
                                        [_directive_tooltip, _ctx.lang().tooltip.edit]
                                      ])
                                    ]),
                                    _: 2
                                  }, 1032, ["href"]),
                                  props.isDone == false ? withDirectives((openBlock(), createBlock(_sfc_main$9, {
                                    key: 0,
                                    type: "button",
                                    onClick: ($event) => (data.deleteOpen = true, data.transaction = transaction),
                                    class: "px-2 py-1.5 rounded-none"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(unref(TrashIcon), { class: "w-4 h-4" })
                                    ]),
                                    _: 2
                                  }, 1032, ["onClick"])), [
                                    [
                                      _directive_tooltip,
                                      _ctx.lang().tooltip.delete
                                    ]
                                  ]) : createCommentVNode("", true)
                                ])
                              ])
                            ])
                          ]);
                        }), 128))
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "flex justify-between items-center p-2 border-t border-slate-200 dark:border-slate-700" }, [
                    createVNode(_sfc_main$c, {
                      links: props.transactions,
                      filters: data.params
                    }, null, 8, ["links", "filters"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Transaction/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
