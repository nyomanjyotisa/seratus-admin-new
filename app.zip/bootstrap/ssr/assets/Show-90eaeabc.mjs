import { unref, withCtx, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { _ as _sfc_main$1 } from "./AuthenticatedLayout-dd3db9f0.mjs";
import "./DeleteUserForm-4f278d6d.mjs";
import "./UpdatePasswordForm-2e057d98.mjs";
import "./UpdateProfileInformationForm-583ab721.mjs";
import _sfc_main$3 from "./UpdateTransactionForm-59a10336.mjs";
import _sfc_main$4 from "./Index-6c69a75a.mjs";
import _sfc_main$5 from "./Index-79875417.mjs";
import _sfc_main$6 from "./Index-d59ab674.mjs";
import _sfc_main$7 from "./Index-483a2673.mjs";
import { Head } from "@inertiajs/vue3";
import { _ as _sfc_main$2 } from "./Breadcrumb-c30f53fb.mjs";
import "./ApplicationLogo-765f8fe2.mjs";
import "@heroicons/vue/24/solid";
import "@vueuse/core";
import "@headlessui/vue";
import "./DangerButton-00cf94ec.mjs";
import "./TextInput-874f017f.mjs";
import "./SecondaryButton-bdd06cd9.mjs";
import "./PrimaryButton-2c41e289.mjs";
import "./SelectInput-1a3ac3f3.mjs";
import "./InfoButton-80e469bc.mjs";
import "lodash";
import "./Create-35eed347.mjs";
import "./Edit-72f8ccc4.mjs";
import "./Delete-9a82a80e.mjs";
import "./DeleteBulk-33d800b6.mjs";
import "./Create-62ffb481.mjs";
import "./Edit-97a5d674.mjs";
import "./Delete-28f5985c.mjs";
import "./DeleteBulk-1d7fabf7.mjs";
import "./Checkbox-89bfd94c.mjs";
import "./Create-587b2853.mjs";
import "./Edit-83cfb10c.mjs";
import "./Delete-49225109.mjs";
import "./DeleteBulk-e77564a9.mjs";
import "./Create-c7aa535a.mjs";
import "./Edit-8ccd9a7d.mjs";
import "./Delete-61e5c6bd.mjs";
import "./DeleteBulk-0d304198.mjs";
const _sfc_main = {
  __name: "Show",
  __ssrInlineRender: true,
  props: {
    transaction: Object,
    sales: Object,
    productions: Object,
    expenses: Object,
    otherIncomes: Object
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Transaction" }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$1, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_sfc_main$2, {
              title: "Transaction",
              breadcrumbs: []
            }, null, _parent2, _scopeId));
            _push2(`<div class="space-y-4"${_scopeId}><div class="p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$3, { transaction: __props.transaction }, null, _parent2, _scopeId));
            _push2(`</div><div class="p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$4, {
              title: "Sale",
              sales: __props.sales,
              transaction: __props.transaction,
              class: "max-w-xl"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$5, {
              title: "Production",
              productions: __props.productions,
              transaction: __props.transaction,
              class: "max-w-xl"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$6, {
              title: "Expense",
              expenses: __props.expenses,
              transaction: __props.transaction,
              class: "max-w-xl"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg"${_scopeId}>`);
            _push2(ssrRenderComponent(_sfc_main$7, {
              title: "Pendapatan Lainnya",
              otherIncomes: __props.otherIncomes,
              transaction: __props.transaction,
              class: "max-w-xl"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode(_sfc_main$2, {
                title: "Transaction",
                breadcrumbs: []
              }),
              createVNode("div", { class: "space-y-4" }, [
                createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode(_sfc_main$3, { transaction: __props.transaction }, null, 8, ["transaction"])
                ]),
                createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode(_sfc_main$4, {
                    title: "Sale",
                    sales: __props.sales,
                    transaction: __props.transaction,
                    class: "max-w-xl"
                  }, null, 8, ["sales", "transaction"])
                ]),
                createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode(_sfc_main$5, {
                    title: "Production",
                    productions: __props.productions,
                    transaction: __props.transaction,
                    class: "max-w-xl"
                  }, null, 8, ["productions", "transaction"])
                ]),
                createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode(_sfc_main$6, {
                    title: "Expense",
                    expenses: __props.expenses,
                    transaction: __props.transaction,
                    class: "max-w-xl"
                  }, null, 8, ["expenses", "transaction"])
                ]),
                createVNode("div", { class: "p-4 sm:p-8 bg-white dark:bg-slate-800 shadow sm:rounded-lg" }, [
                  createVNode(_sfc_main$7, {
                    title: "Pendapatan Lainnya",
                    otherIncomes: __props.otherIncomes,
                    transaction: __props.transaction,
                    class: "max-w-xl"
                  }, null, 8, ["otherIncomes", "transaction"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Transaction/Show.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
