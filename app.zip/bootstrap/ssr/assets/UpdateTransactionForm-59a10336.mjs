import { ref, unref, withCtx, createTextVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { _ as _sfc_main$1, b as _sfc_main$3, a as _sfc_main$4 } from "./TextInput-874f017f.mjs";
import { _ as _sfc_main$5 } from "./PrimaryButton-2c41e289.mjs";
import { _ as _sfc_main$2 } from "./SelectInput-1a3ac3f3.mjs";
import { useForm } from "@inertiajs/vue3";
const _sfc_main = {
  __name: "UpdateTransactionForm",
  __ssrInlineRender: true,
  props: {
    transaction: Object
  },
  setup(__props) {
    const props = __props;
    const isShowUniqueCode = ref(false);
    var date = new Date(props.transaction.date);
    date.setHours(date.getHours() + 8);
    var closed_at = new Date(props.transaction.closed_at);
    closed_at.setHours(closed_at.getHours() + 8);
    if (props.transaction.source == "shopee" || props.transaction.source == "tokped" || props.transaction.source == "etsy" || props.transaction.source == "amazon" || props.transaction.source == "ebay" || props.transaction.source == "website") {
      isShowUniqueCode.value = true;
    } else {
      isShowUniqueCode.value = false;
    }
    const form = useForm({
      unique_code: props.transaction.unique_code,
      description: props.transaction.description,
      status: props.transaction.status,
      source: props.transaction.source,
      date: date.toISOString().slice(0, 10),
      closed_at: props.transaction.closed_at ? closed_at.toISOString().slice(0, 10) : null
    });
    const statuses = [
      {
        value: "pending",
        label: "Pending"
      },
      {
        value: "done",
        label: "Done"
      }
    ];
    const sources = [
      {
        value: "etsy",
        label: "Etsy"
      },
      {
        value: "tokped",
        label: "Tokopedia"
      },
      {
        value: "shopee",
        label: "Shopee"
      },
      {
        value: "novica",
        label: "Novica"
      },
      {
        value: "wa",
        label: "WhatsApp"
      },
      {
        value: "instagram",
        label: "Instagram"
      },
      {
        value: "facebook",
        label: "Facebook"
      },
      {
        value: "email",
        label: "Email"
      },
      {
        value: "amazon",
        label: "Amazon"
      },
      {
        value: "ebay",
        label: "Ebay"
      },
      {
        value: "website",
        label: "Website"
      }
    ];
    const onChange = (event) => {
      if (event.target.value == "shopee" || event.target.value == "tokped" || event.target.value == "etsy" || event.target.value == "amazon" || event.target.value == "ebay" || event.target.value == "website") {
        isShowUniqueCode.value = true;
      } else {
        isShowUniqueCode.value = false;
      }
    };
    console.log(form.date);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(_attrs)}><header><h2 class="text-lg font-medium text-slate-900 dark:text-slate-100"> Edit Detail Transaksi </h2></header><form class="mt-6 space-y-6"><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "source",
        value: "Sumber"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "source",
        class: "mt-1 block w-full",
        modelValue: unref(form).source,
        "onUpdate:modelValue": ($event) => unref(form).source = $event,
        required: "",
        dataSet: sources,
        onChange: ($event) => onChange($event)
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.source
      }, null, _parent));
      _push(`</div>`);
      if (isShowUniqueCode.value) {
        _push(`<div>`);
        _push(ssrRenderComponent(_sfc_main$1, {
          for: "unique_code",
          value: "Unique Code"
        }, null, _parent));
        _push(ssrRenderComponent(_sfc_main$4, {
          id: "unique_code",
          type: "text",
          class: "mt-1 block w-full",
          modelValue: unref(form).unique_code,
          "onUpdate:modelValue": ($event) => unref(form).unique_code = $event,
          required: "",
          autocomplete: "unique_code",
          error: unref(form).errors.unique_code
        }, null, _parent));
        _push(ssrRenderComponent(_sfc_main$3, {
          class: "mt-2",
          message: unref(form).errors.unique_code
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "description",
        value: "Deskripsi"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "description",
        type: "text",
        class: "mt-1 block w-full",
        modelValue: unref(form).description,
        "onUpdate:modelValue": ($event) => unref(form).description = $event,
        required: "",
        error: unref(form).errors.description
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.description
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "date",
        value: "Tanggal"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "date",
        type: "date",
        class: "mt-1 block w-full",
        modelValue: unref(form).date,
        "onUpdate:modelValue": ($event) => unref(form).date = $event,
        placeholder: "ex: Pandil Rama Sita 50 cm",
        error: unref(form).errors.date
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.date
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "status",
        value: "Status"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$2, {
        id: "status",
        class: "mt-1 block w-full",
        modelValue: unref(form).status,
        "onUpdate:modelValue": ($event) => unref(form).status = $event,
        required: "",
        dataSet: statuses
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.description
      }, null, _parent));
      _push(`</div><div>`);
      _push(ssrRenderComponent(_sfc_main$1, {
        for: "closed_at",
        value: "Tanggal Closing"
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$4, {
        id: "closed_at",
        type: "date",
        class: "mt-1 block w-full",
        modelValue: unref(form).closed_at,
        "onUpdate:modelValue": ($event) => unref(form).closed_at = $event,
        placeholder: "ex: Pandil Rama Sita 50 cm",
        error: unref(form).errors.closed_at
      }, null, _parent));
      _push(ssrRenderComponent(_sfc_main$3, {
        class: "mt-2",
        message: unref(form).errors.closed_at
      }, null, _parent));
      _push(`</div><div class="flex items-center gap-4">`);
      _push(ssrRenderComponent(_sfc_main$5, {
        class: { "opacity-25": unref(form).processing },
        disabled: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`${ssrInterpolate(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save)}`);
          } else {
            return [
              createTextVNode(toDisplayString(unref(form).processing ? _ctx.lang().button.save + "..." : _ctx.lang().button.save), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(form).recentlySuccessful) {
        _push(`<p class="text-sm text-slate-600 dark:text-slate-400">${ssrInterpolate(_ctx.lang().profile.saved)}</p>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></form></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Transaction/Partials/UpdateTransactionForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
